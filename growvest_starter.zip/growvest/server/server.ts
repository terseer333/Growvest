import express from 'express';
import crypto from 'crypto';

const app = express();
app.use(express.json());

const users: any[] = [];
const plans = [
  { id: 'p30', name: 'Fixed 30 Days', tenorDays: 30, rateApr: 12.0, minAmount: 5000 },
  { id: 'p90', name: 'Fixed 90 Days', tenorDays: 90, rateApr: 15.0, minAmount: 5000 },
];
const wallets: Record<string, number> = {}; // userId -> kobo
const subs: any[] = [];
const referrals: Record<string, string> = {}; // code -> referrerUserId

function uid() { return crypto.randomUUID(); }

app.post('/auth/register', (req, res) => {
  const { email, password, referralCode } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'email & password required' });
  const id = uid();
  users.push({ id, email, password });
  wallets[id] = 0;
  if (referralCode && referrals[referralCode]) {
    users[users.length - 1].referredBy = referrals[referralCode];
  }
  const myCode = Math.random().toString(36).slice(2, 8).toUpperCase();
  referrals[myCode] = id;
  res.json({ id, email, referralCode: myCode });
});

app.post('/auth/login', (req, res) => {
  const { email, password } = req.body;
  const u = users.find((x:any) => x.email === email && x.password === password);
  if (!u) return res.status(401).json({ error: 'invalid credentials' });
  res.json({ token: 'demo-token', userId: u.id });
});

app.get('/plans', (_, res) => res.json(plans));

app.post('/wallet/fund', (req, res) => {
  const { userId, amount } = req.body;
  if (!wallets[userId] && wallets[userId] !== 0) return res.status(404).json({ error: 'user not found' });
  wallets[userId] += Math.floor(amount * 100);
  res.json({ ok: true, balance: wallets[userId] / 100 });
});

app.post('/invest', (req, res) => {
  const { userId, planId, amount } = req.body;
  const plan = plans.find(p => p.id === planId);
  if (!plan) return res.status(404).json({ error: 'plan not found' });
  const kobo = Math.floor(amount * 100);
  if (wallets[userId] < kobo) return res.status(400).json({ error: 'insufficient funds' });
  wallets[userId] -= kobo;
  const start = new Date();
  const maturity = new Date(start.getTime() + plan.tenorDays * 24 * 60 * 60 * 1000);
  const id = uid();
  subs.push({ id, userId, planId, principalKobo: kobo, start, maturity, accruedKobo: 0, status: 'active' });
  const u = users.find(x => x.id === userId);
  if (u?.referredBy) {
    wallets[u.referredBy] = (wallets[u.referredBy] || 0) + 50000;
    delete u.referredBy;
  }
  res.json({ id, status: 'active' });
});

app.get('/portfolio', (req, res) => {
  const { userId } = req.query as any;
  const mySubs = subs.filter((s:any) => s.userId === userId);
  const now = new Date().getTime();
  const enriched = mySubs.map((s:any) => {
    const plan = plans.find(p => p.id === s.planId)!;
    const days = Math.max(0, Math.floor((Math.min(now, s.maturity.getTime()) - s.start.getTime()) / 86400000));
    const interestKobo = Math.floor((s.principalKobo * (plan.rateApr / 100) / 365) * days);
    const matured = now >= s.maturity.getTime();
    return { ...s, plan, daysAccrued: days, interestNgn: interestKobo / 100, matured };
  });
  res.json(enriched);
});

app.get('/referral/link', (req, res) => {
  const { userId } = req.query as any;
  const code = Object.keys(referrals).find(c => referrals[c] === userId);
  const url = `https://example.com/signup?ref=${code}`;
  res.json({ url, code });
});

app.listen(4000, () => console.log('GrowVest MVP API running on http://localhost:4000'));
