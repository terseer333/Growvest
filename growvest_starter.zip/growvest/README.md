# GrowVest — Starter MVP

This is a ready-to-run starter repo (backend + frontend) for the **GrowVest** MVP demo.

## What’s included
- `server/` — Node + Express + TypeScript demo backend (in-memory store)
- `web/` — Vite + React + TypeScript demo frontend (single-file App)

## How to use
1. Upload this repo to a new GitHub repository named `growvest` (or similar).
2. Open the repo in **GitHub Codespaces** (recommended) or clone locally.

### Run in Codespaces (recommended)
Open a Codespace, then run in one terminal:

cd server
npm install
npx ts-node server.ts

And in a second terminal:

cd web
npm install
npm run dev

Backend defaults to port 4000; frontend to 5173. Both are demo-only (in-memory data).

---

**Notes**: This is an MVP/demo. Do NOT accept real user funds until you add proper payment provider, KYC, database, and legal compliance.
