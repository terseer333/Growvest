import React, { useEffect, useState } from 'react';

export default function App(){ 
  const [user, setUser] = useState<any>(null);
  const [plans, setPlans] = useState<any[]>([]);
  const [amount, setAmount] = useState<number>(5000);
  const [portfolio, setPortfolio] = useState<any[]>([]);

  useEffect(()=>{ fetch('/plans').then(r=>r.json()).then(setPlans); }, []);
  useEffect(()=>{ if(user) refresh(); }, [user]);

  function refresh(){
    fetch(`/portfolio?userId=${user.id}`).then(r=>r.json()).then(setPortfolio);
  }

  async function register(){
    const email = prompt('Email?') || `demo${Math.floor(Math.random()*1000)}@example.com`;
    const res = await fetch('/auth/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, password: 'demo1234' })});
    const data = await res.json();
    setUser({ id: data.id, email: data.email });
  }

  async function fund(){
    if(!user) return alert('Sign up first');
    const res = await fetch('/wallet/fund', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ userId: user.id, amount })});
    const data = await res.json();
    alert('Wallet funded: ₦' + data.balance);
  }

  async function invest(planId:string){
    if(!user) return alert('Sign up first');
    await fetch('/invest', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ userId: user.id, planId, amount })});
    refresh();
    alert('Invested ₦' + amount);
  }

  async function referral(){
    if(!user) return alert('Sign up first');
    const r = await fetch(`/referral/link?userId=${user.id}`);
    const data = await r.json();
    navigator.clipboard.writeText(data.url);
    alert('Referral link copied: ' + data.url);
  }

  return (
    <div style={{ fontFamily: 'Inter, system-ui, sans-serif', padding: 20 }}>
      <header style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <h1>GrowVest (Demo)</h1>
        {!user ? <button onClick={register}>Register (Demo)</button> : <div>Signed in as {user.email}</div>}
      </header>

      {user && (
        <section style={{ marginTop: 12 }}>
          <input type='number' value={amount} onChange={e=>setAmount(parseInt(e.target.value||'0'))} />
          <button onClick={fund} style={{ marginLeft: 8 }}>Fund Wallet (Demo)</button>
          <button onClick={referral} style={{ marginLeft: 8 }}>Copy Referral Link</button>
          <p style={{ color:'#666', fontSize:12 }}>Demo only. Funds and returns are simulated.</p>
        </section>
      )}

      <section style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(220px,1fr))', gap:12, marginTop:20 }}>
        {plans.map(p => (
          <div key={p.id} style={{ border:'1px solid #eee', padding:12, borderRadius:12 }}>
            <div style={{ fontWeight:600 }}>{p.name}</div>
            <div style={{ fontSize:12 }}>Tenor: {p.tenorDays} days</div>
            <div style={{ fontSize:12 }}>APR: {p.rateApr}%</div>
            {user && <button onClick={()=>invest(p.id)} style={{ marginTop:8 }}>Invest ₦{amount}</button>}
          </div>
        ))}
      </section>

      {user && (
        <section style={{ marginTop:20 }}>
          <h3>Portfolio</h3>
          <ul>
            {portfolio.map(s => (
              <li key={s.id} style={{ borderBottom:'1px solid #f2f2f2', padding:8 }}>
                <div style={{ fontWeight:600 }}>{s.plan.name}</div>
                <div style={{ fontSize:12 }}>Days accrued: {s.daysAccrued} • Interest: ₦{s.interestNgn}</div>
                <div style={{ fontSize:12 }}>{s.matured ? 'Matured' : 'Active'}</div>
              </li>
            ))}
          </ul>
        </section>
      )}

      <footer style={{ marginTop:30, fontSize:12, color:'#777' }}>
        Capital at risk. Returns not guaranteed. Demo only.
      </footer>
    </div>
  );
}
